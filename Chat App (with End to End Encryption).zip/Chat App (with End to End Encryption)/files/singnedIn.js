// Here comes the backend .
document.getElementById("enter").addEventListener("click", function () {
var user ;
var user_id = document.getElementById("user_id");
var pass = document.getElementById("user_password");


    var firebaseConfig = {
        apiKey: "AIzaSyDHJpbEx2XTygF5o1bO_T-vQzs5C3WAjT0",
        authDomain: "chat-app-7a586.firebaseapp.com",
        databaseURL: "https://chat-app-7a586.firebaseio.com",
        projectId: "chat-app-7a586",
        storageBucket: "chat-app-7a586.appspot.com",
        messagingSenderId: "465700310113",
        appId: "1:465700310113:web:1ae71c80f920ff25"
    };
    // Initialize Firebase
    firebase.initializeApp(firebaseConfig);
    console.log(firebase);
    var database = firebase.database();
    var reference = database.ref("Accounts");

    reference.on('value', gotData, errData);

    let id_exist = true ;

    function gotData(data) {

        console.log(data.val()); // Working aok !
        var k = data.val();
        var x = Object.keys(k);
        console.log(x); // All ids are taken as an array .
        for (var i = 0; i < x.length; ++i) {
            var a_key = x[i];
            var user = k[a_key]['User Name'];

            // const users = {
            //     user : k[a_key]['User Name'] 
            // };
            if (k[a_key]['User Name'] == user_id.value) {
                let decoded = window.atob(k[a_key].Password);
                if (decoded == pass.value) {
                    coincide = true;
                    user = k[a_key]['User Name'] ;
                    console.log("you got his")
                    window.location.href = `GlobalRoom .html?id=${user}`;
                    break;
                }else{
                    alert("Username or Password doesn't exists !")
                }
            }
        }
    }

    function errData(err) {
        console.log("Error !");
        console.log(err);
    }
});
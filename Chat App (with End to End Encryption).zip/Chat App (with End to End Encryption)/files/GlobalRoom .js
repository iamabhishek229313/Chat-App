var qs = window.location.href ;
var res = qs.split("?");
console.log(res);
var result = res[1].split("=");
var currentUser = result[1];
console.log(currentUser);
let perform = false ;
let record;
var firebaseConfig = {
    apiKey: "AIzaSyDHJpbEx2XTygF5o1bO_T-vQzs5C3WAjT0",
    authDomain: "chat-app-7a586.firebaseapp.com",
    databaseURL: "https://chat-app-7a586.firebaseio.com",
    projectId: "chat-app-7a586",
    storageBucket: "chat-app-7a586.appspot.com",
    messagingSenderId: "465700310113",
    appId: "1:465700310113:web:1ae71c80f920ff25"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
var database;
var reference;
document.getElementById("send").addEventListener('click', function () {
    database = firebase.database();
    reference = database.ref("Messages");
    var lastTimeStampOfUser = Date.now();
    var date = new Date(lastTimeStampOfUser);
    var x = document.getElementById("message").value;
    var encodedMessage = window.btoa(x) ;
    var msg_timestamp = {
        user: currentUser,
        message: encodedMessage,
        timestamp: lastTimeStampOfUser
    };

    reference.push(msg_timestamp) ;

    reference.on('value', knowData, error);
    function knowData(data) {
        var daat = data.val();
        var keyss = Object.keys(daat);
        var lengg = keyss.length ; 
        record = lengg - 1;
    }
    function error(err) {
        if (err) console.log("Error Data !");
    }
    // Now taking Querying about new Data .
    if(!perform)
    setInterval(queryAboutData, 1000) ;
    perform = true ;
});


function queryAboutData() {
    database = firebase.database();
    reference = database.ref("Messages");
    reference.once('value', gotData, errData);
    function gotData(data) {
        var valuated_data = data.val();
        var keys = Object.keys(valuated_data);
        console.log(keys);
        var length = keys.length;
        if (record != length ) {
            if (valuated_data[keys[length - 1]].user != currentUser) {
                var parentDiv = document.getElementById("main_catalog");
                var preParent2 = document.createElement("div");
                preParent2.id = "person_wraper";
                preParent2.style.position = 'relative';
                preParent2.style.width = '100%';
                preParent2.style.height = 'max-content';
                parentDiv.appendChild(preParent2);
                var child_Div2 = document.createElement("div");
                var em = valuated_data[keys[length - 1]].message ;
                var  originalMesaage = window.atob(em);
                child_Div2.innerHTML = originalMesaage ;
                child_Div2.id = "person";
                preParent2.appendChild(child_Div2);
                record = length ;
            } else {
                var msg = document.getElementById("message").value;
                var parentDiv = document.getElementById("main_catalog");
                var preParent = document.createElement("div");
                preParent.id = "user_wraper";
                preParent.style.position = 'relative';
                preParent.style.width = '100%';
                preParent.style.height = 'max-content';
                parentDiv.appendChild(preParent);
                var child_Div = document.createElement("div");
                child_Div.innerHTML = msg;
                child_Div.id = "user";
                preParent.appendChild(child_Div);
                record = length ;
            }
        } else {console.log("Got Nothing ! ")}
    }
    
    function errData(err) {
        if (err) console.log("Error Data !");
    }
}


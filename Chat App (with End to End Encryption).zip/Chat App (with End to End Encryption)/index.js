const express = require('express') ;
const app = express();

const Datastore = require('nedb');

const database = new Datastore('database.db') ;

//database.loadDatabase();


app.listen(8080,()=> console.log("Listening at port 8080"));
app.use(express.static('files'));
// app.use(express.json({limit : '1mb'}));
// app.post('/api' , (request,response) =>{
//     console.log("Got a Request !");
//     const data = request.body ;

//     var timestamp = Date.now() ;

//     data.timestamp = timestamp ;

//     database.insert(data);

//     response.json({
//         status : 'SUCCESS !',
//         timestamp : timestamp ,
//         Mood : request.body.Mood ,
//         latitude : request.body.lat ,
//         longitude : request.body.lon 
//     });;
// });


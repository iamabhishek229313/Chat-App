//Here comes the backend .
document.getElementById("submit").addEventListener('click', function () {
    var name = document.getElementById("Name").value;
    var user_name = document.getElementById("user_name").value;
    var email = document.getElementById("email_id").value;
    var phnNumber = document.getElementById("phn_number").value;
    var ps1 = document.getElementById("password1").value;
    var ps2 = document.getElementById("password2").value;

    var modal_box = document.getElementById("submited");
    //Firebase
    var firebaseConfig = {
        apiKey: "AIzaSyDHJpbEx2XTygF5o1bO_T-vQzs5C3WAjT0",
        authDomain: "chat-app-7a586.firebaseapp.com",
        databaseURL: "https://chat-app-7a586.firebaseio.com",
        projectId: "chat-app-7a586",
        storageBucket: "chat-app-7a586.appspot.com",
        messagingSenderId: "465700310113",
        appId: "1:465700310113:web:1ae71c80f920ff25"
    };
    // Initialize Firebase
    firebase.initializeApp(firebaseConfig);

    console.log(firebase);
    var database = firebase.database();
    var reference = database.ref("Accounts");
    //Password 
    if ((ps1.length < 8)) {
        alert("Password must be of 8 characters .");
    } else {
        if (ps1 == ps2) {
            if (numberCheck(phnNumber)) {
                console.log(phnNumber);
                var new_data = {
                    Name: name,
                    'User Name': user_name,
                    Email: email,
                    "Phone No": phnNumber,
                    "Password": ps1
                };
                reference.push(new_data);
                modal_box.style.display = 'flex';
            } else {
                alert("Phone Number is not Correct .");
            }
            console.log("Password Matched !");
        } else alert("Password doesn't matched !");
    }

    //Number 
    function numberCheck(num) {
        for (var i = 0; i < num.length; i++) {
            if ((num[i] >= 65) || (num[i] <= 90) || (num[i] >= 97) || (num[i] <= 122)) return true;
            else return false;
        }
    }
});